package org.school.personalLoad.service.impl;

import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.school.personalLoad.dto.SubjectCreateRequest;
import org.school.personalLoad.model.SubjectCatalogEntry;
import org.school.personalLoad.model.SubjectAreaNames;
import org.school.personalLoad.model.SubjectArea;
import org.school.personalLoad.model.SubjectType;
import org.school.personalLoad.repository.SubjectAreaRepository;
import org.school.personalLoad.repository.SubjectCatalogRepository;
import org.school.personalLoad.service.SubjectCatalogService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.*;

@Service
@RequiredArgsConstructor
public class SubjectCatalogServiceImpl implements SubjectCatalogService {

    private final SubjectCatalogRepository repository;
    private final SubjectAreaRepository subjectAreaRepository;

    @Override
    public SubjectCatalogEntry create(SubjectCreateRequest request) {
        String name = validateName(request);
        SubjectType type = validateType(request);

        return repository.findBySubjectNameAndSubjectType(name, type)
                .orElseGet(() -> {
                    SubjectCatalogEntry entry = new SubjectCatalogEntry();
                    entry.setSubjectName(name);
                    entry.setSubjectType(type);
                    SubjectArea area = resolveArea(request.getSubjectAreaId(), request.getSubjectAreaName());
                    entry.setSubjectAreaRef(area);
                    entry.setSubjectAreaName(area.getName());
                    entry.setSubjectCoefficient(resolveCoefficient(request.getSubjectCoefficient()));
                    return repository.save(entry);
                });
    }

    @Override
    @Transactional
    public SubjectCatalogEntry update(Long id, SubjectCreateRequest request) {
        String name = validateName(request);
        SubjectType type = validateType(request);

        SubjectCatalogEntry existing = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Subject not found"));

        repository.findBySubjectNameAndSubjectType(name, type)
                .filter(found -> !Objects.equals(found.getId(), id))
                .ifPresent(found -> {
                    throw new IllegalArgumentException("Предмет с таким названием и типом уже существует");
                });

        SubjectArea area = resolveArea(request.getSubjectAreaId(), request.getSubjectAreaName());
        existing.setSubjectName(name);
        existing.setSubjectType(type);
        existing.setSubjectAreaRef(area);
        existing.setSubjectAreaName(area.getName());
        existing.setSubjectCoefficient(resolveCoefficient(request.getSubjectCoefficient()));
        return repository.save(existing);
    }

    @Override
    public void deleteById(Long id) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Subject not found");
        }
        try {
            repository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new IllegalArgumentException("Нельзя удалить предмет: он используется в учебном плане/нагрузке");
        }
    }

    @Override
    public List<SubjectCatalogEntry> findAll() {
        return repository.findAll();
    }

    @Override
    public void clearAll() {
        repository.deleteAll();
    }

    @Override
    public Map<String, Object> importFromExcel(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Файл обязателен");
        }

        int imported = 0;
        int skipped = 0;
        Set<String> seen = new HashSet<>();

        try (InputStream inputStream = file.getInputStream(); Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getNumberOfSheets() > 0 ? workbook.getSheetAt(0) : null;
            if (sheet == null) {
                throw new IllegalArgumentException("Лист с предметами не найден");
            }

            for (int i = 0; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String subjectName = cellValue(row.getCell(0));
                if (subjectName.isBlank() || subjectName.equalsIgnoreCase("предмет")) {
                    skipped++;
                    continue;
                }

                String typeRaw = cellValue(row.getCell(1));
                SubjectType type = parseType(typeRaw);
                if (type == null) {
                    skipped++;
                    continue;
                }

                Long subjectAreaId = parseLong(cellValue(row.getCell(4)));
                SubjectArea area = resolveArea(subjectAreaId, cellValue(row.getCell(2)));
                java.math.BigDecimal coefficient = resolveCoefficient(parseDecimal(cellValue(row.getCell(3))));

                String key = subjectName.trim().toLowerCase() + "|" + type.name();
                if (!seen.add(key)) {
                    skipped++;
                    continue;
                }

                Optional<SubjectCatalogEntry> existing =
                        repository.findBySubjectNameAndSubjectType(subjectName.trim(), type);

                if (existing.isPresent()) {
                    SubjectCatalogEntry entry = existing.get();
                    entry.setSubjectAreaRef(area);
                    entry.setSubjectAreaName(area.getName());
                    entry.setSubjectCoefficient(coefficient);
                    repository.save(entry);
                    imported++;
                    continue;
                }

                SubjectCatalogEntry entry = new SubjectCatalogEntry();
                entry.setSubjectName(subjectName.trim());
                entry.setSubjectType(type);
                entry.setSubjectAreaRef(area);
                entry.setSubjectAreaName(area.getName());
                entry.setSubjectCoefficient(coefficient);
                repository.save(entry);
                imported++;
            }

            return Map.of("status", "ok", "imported", imported, "skipped", skipped);
        } catch (Exception e) {
            throw new RuntimeException("Не удалось импортировать предметы", e);
        }
    }

    @Override
    public Resource buildImportTemplate() {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Предметы");
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Предмет");
            header.createCell(1).setCellValue("Тип");
            header.createCell(2).setCellValue("Предметная область");
            header.createCell(3).setCellValue("Коэффициент");
            header.createCell(4).setCellValue("SUBJECT_AREA_ID");

            List<SubjectCatalogEntry> rows = repository.findAll();
            if (rows.isEmpty()) {
                Row ex1 = sheet.createRow(1);
                ex1.createCell(0).setCellValue("Математика");
                ex1.createCell(1).setCellValue("1");
                ex1.createCell(2).setCellValue("Математика и информатика");
                ex1.createCell(3).setCellValue("1");
                ex1.createCell(4).setCellValue("");

                Row ex2 = sheet.createRow(2);
                ex2.createCell(0).setCellValue("Физика");
                ex2.createCell(1).setCellValue("2");
                ex2.createCell(2).setCellValue("Естественно-научные предметы");
                ex2.createCell(3).setCellValue("1");
                ex2.createCell(4).setCellValue("");

                Row ex3 = sheet.createRow(3);
                ex3.createCell(0).setCellValue("Разговоры о важном");
                ex3.createCell(1).setCellValue("3");
                ex3.createCell(2).setCellValue("Общественно-научные предметы");
                ex3.createCell(3).setCellValue("1");
                ex3.createCell(4).setCellValue("");
            } else {
                rows.sort(Comparator.comparing(SubjectCatalogEntry::getSubjectName, String.CASE_INSENSITIVE_ORDER));
                int idx = 1;
                for (SubjectCatalogEntry entry : rows) {
                    Row row = sheet.createRow(idx++);
                    row.createCell(0).setCellValue(entry.getSubjectName());
                    row.createCell(1).setCellValue(exportTypeCode(entry.getSubjectType()));
                    row.createCell(2).setCellValue(resolveAreaNameForExport(entry.getSubjectAreaName()));
                    row.createCell(3).setCellValue(resolveCoefficient(entry.getSubjectCoefficient()).toPlainString());
                    if (entry.getSubjectAreaId() != null) row.createCell(4).setCellValue(entry.getSubjectAreaId());
                }
            }

            sheet.autoSizeColumn(0);
            sheet.autoSizeColumn(1);
            sheet.autoSizeColumn(2);
            sheet.autoSizeColumn(3);
            sheet.autoSizeColumn(4);
            workbook.write(out);
            return new ByteArrayResource(out.toByteArray());
        } catch (Exception e) {
            throw new RuntimeException("Не удалось сформировать шаблон", e);
        }
    }

    private String validateName(SubjectCreateRequest request) {
        if (request == null || request.getSubjectName() == null || request.getSubjectName().isBlank()) {
            throw new IllegalArgumentException("subjectName is required");
        }
        return request.getSubjectName().trim();
    }

    private SubjectType validateType(SubjectCreateRequest request) {
        if (request.getSubjectType() == null) {
            throw new IllegalArgumentException("subjectType is required");
        }
        return request.getSubjectType();
    }

    private SubjectArea resolveArea(Long subjectAreaId, String subjectAreaName) {
        if (subjectAreaId != null) {
            return subjectAreaRepository.findById(subjectAreaId)
                    .orElseThrow(() -> new IllegalArgumentException("subject_area_id not found: " + subjectAreaId));
        }
        String areaName = SubjectAreaNames.resolveBaseArea(subjectAreaName);
        return subjectAreaRepository.findByNameIgnoreCase(areaName)
                .orElseThrow(() -> new IllegalArgumentException("Предметная область не найдена для deprecated subjectAreaName fallback: " + areaName));
    }

    private Long parseLong(String value) {
        String normalized = value == null ? "" : value.trim();
        if (normalized.isBlank()) return null;
        try { return Long.parseLong(normalized.replaceAll("\\.0$", "")); }
        catch (Exception e) { return null; }
    }

    private String resolveAreaNameForExport(String value) {
        try {
            return SubjectAreaNames.resolveBaseArea(value);
        } catch (IllegalArgumentException ex) {
            return SubjectAreaNames.defaultArea();
        }
    }

    private java.math.BigDecimal resolveCoefficient(java.math.BigDecimal value) {
        if (value == null || value.compareTo(java.math.BigDecimal.ZERO) <= 0) {
            return java.math.BigDecimal.ONE;
        }
        return value;
    }

    private java.math.BigDecimal parseDecimal(String value) {
        String normalized = value == null ? "" : value.trim().replace(',', '.');
        if (normalized.isBlank()) return null;
        try { return new java.math.BigDecimal(normalized); }
        catch (Exception ignored) { return null; }
    }

    private String cellValue(Cell cell) {
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue().trim();
            case NUMERIC -> String.valueOf((int) cell.getNumericCellValue()).trim();
            case FORMULA -> {
                try {
                    yield cell.getStringCellValue().trim();
                } catch (Exception e) {
                    yield "";
                }
            }
            default -> "";
        };
    }

    private SubjectType parseType(String value) {
        String v = String.valueOf(value == null ? "" : value).trim().toLowerCase();
        if (v.isBlank()) return SubjectType.CORE;
        if (v.contains("коррек") || v.contains("correction")) return SubjectType.CORRECTIONAL;
        if (v.contains("внеур")) return SubjectType.EXTRACURRICULAR;
        if (v.contains("формир") || v.contains("formable")) return SubjectType.FORMABLE;
        if (v.contains("основ") || v.contains("core")) return SubjectType.CORE;
        if (v.equals("1")) return SubjectType.CORE;
        if (v.equals("2")) return SubjectType.FORMABLE;
        if (v.equals("3")) return SubjectType.EXTRACURRICULAR;
        if (v.equals("4")) return SubjectType.CORRECTIONAL;
        if (v.equals("core_formable")) return SubjectType.CORE;
        return null;
    }

    private String exportTypeCode(SubjectType type) {
        if (type == SubjectType.CORRECTIONAL) return "4";
        if (type == SubjectType.EXTRACURRICULAR) return "3";
        if (type == SubjectType.FORMABLE) return "2";
        if (type == SubjectType.CORE || type == SubjectType.CORE_FORMABLE) return "1";
        return "1";
    }
}
