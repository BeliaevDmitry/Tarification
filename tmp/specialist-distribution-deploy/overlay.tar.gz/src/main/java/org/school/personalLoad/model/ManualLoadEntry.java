package org.school.personalLoad.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "manual_load_entry", uniqueConstraints = {
        @UniqueConstraint(name = "uk_manual_load_iup_assignment", columnNames = {"source_iup_assignment_id"})
})
public class ManualLoadEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String academicYear;

    @Column(nullable = false)
    private String fioTeacher;

    @Column(name = "teacher_id")
    private Long teacherId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "teacher_id", insertable = false, updatable = false)
    @JsonIgnore
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private TeacherDirectoryEntry teacher;

    @Column(nullable = false)
    private String numberSchoolBuilding;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "building_group_id", insertable = false, updatable = false)
    @JsonIgnore
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private BuildingGroup buildingGroup;

    @Column(name = "school_building_id")
    private Long schoolBuildingId;

    @Column(nullable = false)
    private String subjectName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subject_id")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private SubjectCatalogEntry subject;

    public Long getSubjectId() {
        return subject == null ? null : subject.getId();
    }

    @Column(nullable = false)
    private String className;

    @Column(name = "class_id")
    private Long classId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "class_id", insertable = false, updatable = false)
    @JsonIgnore
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private ClassroomLeadershipEntry classRef;

    @Column(name = "meta_group_id")
    private Long metaGroupId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "meta_group_id", insertable = false, updatable = false)
    @JsonIgnore
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private MetaGroup metaGroupRef;


    public Long getSchoolBuildingId() {
        if (schoolBuildingId != null) {
            return schoolBuildingId;
        }
        if (metaGroupRef != null && metaGroupRef.getSchoolBuildingId() != null) {
            return metaGroupRef.getSchoolBuildingId();
        }
        if (classRef != null) {
            return classRef.getSchoolBuildingId();
        }
        return null;
    }

    @Column(nullable = false)
    private Integer load;

    @Enumerated(EnumType.STRING)
    @Column(name = "load_source", nullable = false, columnDefinition = "varchar(16) default 'CORE'")
    private ManualLoadSource loadSource = ManualLoadSource.CORE;

    /**
     * The decimal-capable column is retained for stored-data compatibility, but new
     * IUP assignments are validated as whole hours. This value is authoritative only
     * for IUP rows; ordinary load still uses the legacy load/groupLoad columns.
     */
    @Column(name = "precise_load_hours", precision = 10, scale = 2)
    private BigDecimal preciseLoadHours;

    @Column(name = "source_iup_plan_id")
    private Long sourceIupPlanId;

    @Column(name = "source_iup_assignment_id")
    private Long sourceIupAssignmentId;

    @Column(name = "source_student_id")
    private Long sourceStudentId;

    @Enumerated(EnumType.STRING)
    @Column(name = "iup_student_category")
    private StudentCategory iupStudentCategory;

    @JsonIgnore
    @Column(name = "employment_contract_id")
    private Long employmentContractId;

    @JsonIgnore
    @Column(name = "included_in_rate_hours", precision = 10, scale = 2)
    private BigDecimal includedInRateHours;

    @JsonIgnore
    @Column(name = "in_rate_allocation_confirmed", nullable = false, columnDefinition = "boolean default false")
    private boolean inRateAllocationConfirmed = false;

    @JsonIgnore
    @Column(name = "in_rate_reason", length = 1000)
    private String inRateReason;

    @JsonIgnore
    @Column(name = "in_rate_updated_at")
    private LocalDateTime inRateUpdatedAt;

    @JsonIgnore
    @Column(name = "in_rate_updated_by")
    private String inRateUpdatedBy;

    private String groupNameEducationalPlan;

    private Integer groupLoad;

    @Column(name = "curriculum_module_id")
    private Long curriculumModuleId;

    @Enumerated(EnumType.STRING)
    @Column(name = "curriculum_part")
    private CurriculumPart curriculumPart = CurriculumPart.CORE;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EducationLevel educationLevel;

    @Enumerated(EnumType.STRING)
    private StudyPeriod studyPeriod;

    private LocalDate loadFromDate;

    private LocalDate loadToDate;

    private LocalDate backupLoadToDate;

    @Column(nullable = false)
    private boolean dismissalAdjusted = false;

    @Column(nullable = false)
    private boolean orphaned = false;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ContinuityStatus continuityStatus = ContinuityStatus.UNKNOWN;

    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public boolean isIupLoad() {
        return loadSource == ManualLoadSource.IUP;
    }

    public BigDecimal getEffectiveLoadHours() {
        if (isIupLoad() && preciseLoadHours != null) {
            return preciseLoadHours.max(BigDecimal.ZERO);
        }
        int value = groupLoad != null ? groupLoad : (load == null ? 0 : load);
        return BigDecimal.valueOf(Math.max(value, 0));
    }
}
