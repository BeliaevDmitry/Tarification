package org.school.personalLoad.service.impl;

import org.junit.jupiter.api.BeforeEach;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.jupiter.MockitoExtension;
import org.school.personalLoad.model.*;
import org.springframework.mock.web.MockMultipartFile;
import org.school.personalLoad.dto.ManualLoadBulkRequest;
import org.school.personalLoad.dto.ManualLoadEntryRequest;
import org.school.personalLoad.dto.ManualLoadHealthResponse;
import org.school.personalLoad.dto.ManualLoadStatsResponse;
import org.school.personalLoad.repository.ManualLoadEntryRepository;
import org.school.personalLoad.repository.CurriculumPlanEntryRepository;
import org.school.personalLoad.repository.SalarySettingsRepository;
import org.school.personalLoad.repository.SchoolBuildingRepository;
import org.school.personalLoad.repository.ClassroomLeadershipRepository;
import org.school.personalLoad.repository.ContingentSnapshotRepository;
import org.school.personalLoad.repository.ContingentStudentRepository;
import org.school.personalLoad.repository.TeacherDirectoryRepository;
import org.school.personalLoad.repository.SubjectCatalogRepository;
import org.school.personalLoad.repository.SubjectLevelCoefficientRepository;
import org.school.personalLoad.repository.SalaryGroupCoefficientSubjectRepository;
import org.school.personalLoad.repository.MetaGroupRepository;
import org.school.personalLoad.service.ClassSizeService;
import org.school.personalLoad.service.PrimarySubjectService;
import org.school.personalLoad.service.CurriculumPlanService;
import org.school.personalLoad.service.DatabaseService;
import org.school.personalLoad.service.StudyPeriodSettingService;
import org.school.personalLoad.service.TarifficationProcessingService;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.anyString;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class ManualLoadServiceImplBulkReplaceTest {

    @Mock
    private ManualLoadEntryRepository manualLoadEntryRepository;
    @Mock
    private TarifficationProcessingService tarifficationProcessingService;
    @Mock
    private DatabaseService databaseService;
    @Mock
    private CurriculumPlanService curriculumPlanService;
    @Mock
    private CurriculumPlanEntryRepository curriculumPlanEntryRepository;
    @Mock
    private StudyPeriodSettingService studyPeriodSettingService;
    @Mock
    private TeacherDirectoryRepository teacherDirectoryRepository;
    @Mock
    private SubjectCatalogRepository subjectCatalogRepository;
    @Mock
    private SubjectLevelCoefficientRepository subjectLevelCoefficientRepository;
    @Mock
    private ClassroomLeadershipRepository classroomLeadershipRepository;
    @Mock
    private ContingentSnapshotRepository contingentSnapshotRepository;
    @Mock
    private ContingentStudentRepository contingentStudentRepository;
    @Mock
    private SchoolBuildingRepository schoolBuildingRepository;
    @Mock
    private SalarySettingsRepository salarySettingsRepository;
    @Mock
    private SalaryGroupCoefficientSubjectRepository salaryGroupCoefficientSubjectRepository;
    @Mock
    private MetaGroupRepository metaGroupRepository;
    @Mock
    private PrimarySubjectService primarySubjectService;
    @Mock
    private ClassSizeService classSizeService;
    private org.school.personalLoad.service.LoadSalaryCalculationService loadSalaryCalculationService;

    private ManualLoadServiceImpl service;

    @BeforeEach
    void setUp() {
        loadSalaryCalculationService = new org.school.personalLoad.service.LoadSalaryCalculationService(
                classSizeService, salarySettingsRepository, subjectLevelCoefficientRepository,
                salaryGroupCoefficientSubjectRepository,
                new org.school.personalLoad.service.IupCompensationCalculator());
        lenient().when(metaGroupRepository.findById(any()))
                .thenAnswer(invocation -> Optional.of(metaGroup(invocation.getArgument(0), 36L)));
        TeacherDirectoryEntry teacher = teacher(10L, "Иванов И.И.");
        TeacherDirectoryEntry vacancy = teacher(11L, "Вакансия");
        SubjectCatalogEntry algebra = subject(20L, "Алгебра");
        SubjectCatalogEntry math = subject(21L, "Математика");
        SubjectCatalogEntry ethics = subject(22L, "ОРКСЭ");
        SubjectCatalogEntry physics = subject(23L, "Физика");
        SubjectCatalogEntry odnknr = subject(24L, "ОДНКНР");
        lenient().when(teacherDirectoryRepository.findAll()).thenReturn(List.of(teacher, vacancy));
        lenient().when(teacherDirectoryRepository.findByFioTeacherIgnoreCase("Иванов И.И.")).thenReturn(Optional.of(teacher));
        lenient().when(teacherDirectoryRepository.findByFioTeacherIgnoreCase("Вакансия")).thenReturn(Optional.of(vacancy));
        lenient().when(teacherDirectoryRepository.findById(10L)).thenReturn(Optional.of(teacher));
        lenient().when(teacherDirectoryRepository.findById(11L)).thenReturn(Optional.of(vacancy));
        lenient().when(subjectCatalogRepository.findAll()).thenReturn(List.of(algebra, math, ethics, physics, odnknr));
        lenient().when(subjectLevelCoefficientRepository.findAll()).thenReturn(List.of());
        lenient().when(salaryGroupCoefficientSubjectRepository.findAll()).thenReturn(List.of());
        lenient().when(subjectCatalogRepository.findById(20L)).thenReturn(Optional.of(algebra));
        lenient().when(subjectCatalogRepository.findById(21L)).thenReturn(Optional.of(math));
        lenient().when(subjectCatalogRepository.findById(22L)).thenReturn(Optional.of(ethics));
        lenient().when(subjectCatalogRepository.findById(23L)).thenReturn(Optional.of(physics));
        lenient().when(subjectCatalogRepository.findById(24L)).thenReturn(Optional.of(odnknr));
        lenient().when(classroomLeadershipRepository.findById(any()))
                .thenAnswer(invocation -> Optional.of(classEntry(invocation.getArgument(0), "СП1", "7-А", "ул. Первая, 1")));

        service = new ManualLoadServiceImpl(
                manualLoadEntryRepository,
                tarifficationProcessingService,
                databaseService,
                curriculumPlanService,
                curriculumPlanEntryRepository,
                studyPeriodSettingService,
                teacherDirectoryRepository,
                subjectCatalogRepository,
                subjectLevelCoefficientRepository,
                classroomLeadershipRepository,
                contingentSnapshotRepository,
                contingentStudentRepository,
                schoolBuildingRepository,
                salarySettingsRepository,
                salaryGroupCoefficientSubjectRepository,
                metaGroupRepository,
                primarySubjectService,
                classSizeService,
                loadSalaryCalculationService
        );
    }

    @Test
    void createOrdinaryManualLoadPersistsTeacherIdAndSubjectIdWithSnapshots() {
        ManualLoadEntryRequest request = manualRequest("СП1", "7-А", 701L);
        request.setTeacherId(10L);
        request.setSubjectId(20L);
        when(manualLoadEntryRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        ManualLoadEntry saved = service.create(request);

        assertEquals(10L, saved.getTeacherId());
        assertEquals("Иванов И.И.", saved.getFioTeacher());
        assertEquals(20L, saved.getSubjectId());
        assertEquals("Алгебра", saved.getSubjectName());
        assertEquals(701L, saved.getClassId());
        assertNull(saved.getMetaGroupId());
    }

    @Test
    void createExplicitMetaGroupManualLoadPersistsMetaTeacherAndSubjectFks() {
        ManualLoadEntryRequest request = manualRequest("СП1", "МГ:5 ФИЗИКА", null);
        request.setTeacherId(10L);
        request.setSubjectId(23L);
        request.setSubjectName("Физика");
        request.setMetaGroupId(501L);
        when(metaGroupRepository.findById(501L)).thenReturn(Optional.of(metaGroup(501L, 36L)));
        when(manualLoadEntryRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        ManualLoadEntry saved = service.create(request);

        assertNull(saved.getClassId());
        assertEquals(501L, saved.getMetaGroupId());
        assertEquals(10L, saved.getTeacherId());
        assertEquals(23L, saved.getSubjectId());
    }

    @Test
    void buildingGroupCreateBulkForSingleAddressBuildingIsAllowed() {
        ManualLoadEntryRequest request = manualRequest("B1", "8-А", 1L);
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026"))
                .thenReturn(List.of(classEntry(1L, "B1", "8-А", "ул. Одна, 1")));
        when(manualLoadEntryRepository.saveAll(any())).thenAnswer(invocation -> invocation.getArgument(0));

        service.createBulk(List.of(request));

        verify(manualLoadEntryRepository).deleteByAcademicYearAndBuildingCodes("2025/2026", java.util.Set.of("b1"));
        verify(manualLoadEntryRepository).saveAll(any());
    }

    @Test
    void buildingGroupCreateBulkForMultiAddressBuildingIsRejectedWithoutDeleteOrSave() {
        ManualLoadEntryRequest request = manualRequest("СП3", "4-Д", 1L);
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026"))
                .thenReturn(List.of(
                        classEntry(1L, "СП3", "4-Д", "Кравченко, д.14, корп.1"),
                        classEntry(2L, "СП3", "4-И", "Марии Ульяновой, д.7")
                ));

        assertThrows(IllegalArgumentException.class, () -> service.createBulk(List.of(request)));

        verify(manualLoadEntryRepository, never())
                .deleteByAcademicYearAndBuildingCodes(org.mockito.ArgumentMatchers.anyString(), org.mockito.ArgumentMatchers.any());
        verify(manualLoadEntryRepository, never()).saveAll(any());
    }

    @Test
    void explicitBuildingGroupCreateBulkForMultiAddressBuildingIsAllowed() {
        ManualLoadEntryRequest request = manualRequest("СП3", "4-Д", 1L);
        ManualLoadBulkRequest bulk = new ManualLoadBulkRequest();
        bulk.setAcademicYear("2025/2026");
        bulk.setScopeType("BUILDING_GROUP");
        bulk.setNumberSchoolBuilding("СП3");
        bulk.setRows(List.of(request));
        when(manualLoadEntryRepository.saveAll(any())).thenAnswer(invocation -> invocation.getArgument(0));

        service.createBulk(bulk);

        verify(manualLoadEntryRepository).deleteByAcademicYearAndBuildingCodes("2025/2026", java.util.Set.of("сп3"));
        verify(manualLoadEntryRepository).saveAll(any());
    }

    @Test
    void createBulkForAddressScopeReplacesOnlySelectedClassIds() {
        ManualLoadEntryRequest request = manualRequest("СП3", "4-Д", 9119L);

        ManualLoadBulkRequest bulk = new ManualLoadBulkRequest();
        bulk.setAcademicYear("2025/2026");
        bulk.setScopeType("BUILDING_ADDRESS");
        bulk.setNumberSchoolBuilding("СП3");
        bulk.setCampusAddress("Марии Ульяновой, д.7");
        bulk.setSchoolBuildingId(36L);
        bulk.setClassIds(new java.util.LinkedHashSet<>(java.util.List.of(9119L, 9166L, 9139L)));
        bulk.setRows(List.of(request));

        when(classroomLeadershipRepository.findAllById(org.mockito.ArgumentMatchers.any()))
                .thenReturn(List.of(
                        classEntry(9119L, "СП3", "4-Д", "Марии Ульяновой, д.7", 36L),
                        classEntry(9166L, "СП3", "4-И", "Марии Ульяновой, д.7", 36L),
                        classEntry(9139L, "СП3", "4-К", "Марии Ульяновой, д.7", 36L)
                ));
        when(manualLoadEntryRepository.saveAll(any())).thenAnswer(invocation -> invocation.getArgument(0));

        service.createBulk(bulk);

        verify(manualLoadEntryRepository).deleteByAcademicYearAndClassIds(
                "2025/2026",
                new java.util.LinkedHashSet<>(java.util.List.of(9119L, 9166L, 9139L))
        );
        verify(manualLoadEntryRepository, org.mockito.Mockito.never())
                .deleteByAcademicYearAndBuildingCodes(org.mockito.ArgumentMatchers.anyString(), org.mockito.ArgumentMatchers.any());
        verify(manualLoadEntryRepository).saveAll(any());
    }

    @Test
    void createBulkForAddressScopeRejectsClassIdFromAnotherAddress() {
        ManualLoadEntryRequest request = manualRequest("СП3", "4-Д", 9119L);

        ManualLoadBulkRequest bulk = new ManualLoadBulkRequest();
        bulk.setAcademicYear("2025/2026");
        bulk.setScopeType("BUILDING_ADDRESS");
        bulk.setNumberSchoolBuilding("СП3");
        bulk.setCampusAddress("Марии Ульяновой, д.7");
        bulk.setSchoolBuildingId(36L);
        bulk.setClassIds(new java.util.LinkedHashSet<>(java.util.List.of(9119L, 9166L)));
        bulk.setRows(List.of(request));

        when(classroomLeadershipRepository.findAllById(any()))
                .thenReturn(List.of(
                        classEntry(9119L, "СП3", "4-Д", "Марии Ульяновой, д.7", 36L),
                        classEntry(9166L, "СП3", "4-И", "Кравченко, д.14, корп.1", 38L)
                ));

        assertThrows(IllegalArgumentException.class, () -> service.createBulk(bulk));

        verify(manualLoadEntryRepository, never()).deleteByAcademicYearAndClassIds(org.mockito.ArgumentMatchers.anyString(), org.mockito.ArgumentMatchers.any());
        verify(manualLoadEntryRepository, never()).saveAll(any());
    }

    @Test
    void deleteMultiAddressBuildingRequiresExplicitBuildingGroupScope() {
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026"))
                .thenReturn(List.of(
                        classEntry(1L, "СП3", "4-Д", "Кравченко, д.14, корп.1"),
                        classEntry(2L, "СП3", "4-И", "Марии Ульяновой, д.7")
                ));

        assertThrows(IllegalArgumentException.class, () -> service.clearByBuilding("2025/2026", "СП3"));

        verify(manualLoadEntryRepository, never())
                .deleteByAcademicYearAndBuildingCodes(org.mockito.ArgumentMatchers.anyString(), org.mockito.ArgumentMatchers.any());

        service.clearByBuilding("2025/2026", "СП3", "BUILDING_GROUP");

        verify(manualLoadEntryRepository).deleteByAcademicYearAndBuildingCodes("2025/2026", java.util.List.of("сп3"));
    }


    @Test
    void exportTemplateIncludesStandaloneClassOnceAndSkipsOrdinaryMetaMemberRows() throws Exception {
        CurriculumPlanEntry standalone = curriculumRow("СП1", "5-А", "Математика", 5);
        standalone.setClassId(101L);
        CurriculumPlanEntry metaMember = curriculumRow("СП1", "5-Б", "Физика", 3);
        metaMember.setClassId(102L);
        metaMember.setMetaGroup(true);
        metaMember.setExcludedFromManualLoad(true);
        CurriculumPlanEntry explicitMeta = curriculumRow("СП1", "МГ:5 ФИЗИКА", "Физика", 3);
        explicitMeta.setMetaGroupId(501L);

        when(curriculumPlanService.findAll("2025/2026")).thenReturn(List.of(standalone, metaMember, explicitMeta));
        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of());
        when(studyPeriodSettingService.resolveDateRange(anyString(), anyString(), any()))
                .thenReturn(new StudyPeriodSettingService.DateRange(LocalDate.of(2025, 9, 1), LocalDate.of(2026, 5, 31)));

        byte[] body = service.exportWorkbook("2025/2026");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var sheet = workbook.getSheet("LOAD_EDITABLE");
            assertEquals(2, sheet.getLastRowNum());
            assertEquals("Математика", sheet.getRow(1).getCell(3).getStringCellValue());
            assertEquals(101L, (long) sheet.getRow(1).getCell(12).getNumericCellValue());
            assertEquals("МГ:5 ФИЗИКА", sheet.getRow(2).getCell(2).getStringCellValue());
            assertEquals(501L, (long) sheet.getRow(2).getCell(13).getNumericCellValue());
            assertFalse(sheet.getRow(1).getCell(2).getStringCellValue().equals("5-Б"));
            assertEquals("CLASS_ID", sheet.getRow(0).getCell(12).getStringCellValue());
            assertEquals("META_GROUP_ID", sheet.getRow(0).getCell(13).getStringCellValue());
            assertEquals("CURRICULUM_PART", sheet.getRow(0).getCell(16).getStringCellValue());
            assertEquals("CORE", sheet.getRow(1).getCell(16).getStringCellValue());
        }
    }

    @Test
    void explicitMetaGroupLoadRequestIsSavedByMetaGroupIdWithoutClassId() {
        ManualLoadEntryRequest request = manualRequest("СП1", "МГ:5 ФИЗИКА", null);
        request.setMetaGroupId(501L);
        ManualLoadBulkRequest bulk = new ManualLoadBulkRequest();
        bulk.setAcademicYear("2025/2026");
        bulk.setScopeType("BUILDING_GROUP");
        bulk.setNumberSchoolBuilding("СП1");
        bulk.setRows(List.of(request));
        when(manualLoadEntryRepository.saveAll(any())).thenAnswer(invocation -> invocation.getArgument(0));

        List<ManualLoadEntry> saved = service.createBulk(bulk);

        assertEquals(1, saved.size());
        assertEquals(501L, saved.get(0).getMetaGroupId());
        assertEquals(null, saved.get(0).getClassId());
    }

    @Test
    void statsAndHealthCountExplicitMetaGroupPlanWithoutOrdinaryMemberDuplicate() {
        CurriculumPlanEntry metaMember = curriculumRow("СП1", "5-Б", "Физика", 3);
        metaMember.setClassId(102L);
        metaMember.setMetaGroup(true);
        metaMember.setExcludedFromManualLoad(true);
        CurriculumPlanEntry explicitMeta = curriculumRow("СП1", "МГ:5 ФИЗИКА", "Физика", 3);
        explicitMeta.setMetaGroupId(501L);
        ManualLoadEntry assignedMeta = manualRow("Иванов И.И.", "СП1", "МГ:5 ФИЗИКА", "Физика", 3);
        assignedMeta.setMetaGroupId(501L);

        when(curriculumPlanService.findAll("2025/2026", "СП1")).thenReturn(List.of(metaMember, explicitMeta));
        when(manualLoadEntryRepository.findAllByAcademicYearAndNumberSchoolBuildingIgnoreCase("2025/2026", "СП1"))
                .thenReturn(List.of(assignedMeta));
        SubjectCatalogEntry subject = new SubjectCatalogEntry();
        subject.setSubjectName("Физика");
        subject.setSubjectAreaName("Естественные науки");

        ManualLoadStatsResponse stats = service.buildStats("2025/2026", "СП1", 0, 20);
        ManualLoadHealthResponse health = service.buildHealth("2025/2026", "СП1");

        assertEquals(3, stats.getTotalPlanned());
        assertEquals(3, stats.getTotalAssigned());
        assertEquals(0, stats.getTotalUnassigned());
        assertEquals(0, health.getUnassignedHours());
    }

    @Test
    void validateMetaGroupLoadUsesMetaGroupIdRule() {
        ManualLoadEntry assignedMeta = manualRow("Иванов И.И.", "СП1", "МГ:5 ФИЗИКА", "Физика", 3);
        assignedMeta.setMetaGroupId(501L);
        assignedMeta.setSubject(subject(23L, "Физика"));
        CurriculumPlanEntry explicitMeta = curriculumRow("СП1", "МГ:5 ФИЗИКА", "Физика", 3);
        explicitMeta.setMetaGroupId(501L);
        explicitMeta.setSubject(subject(23L, "Физика"));
        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(assignedMeta));
        when(curriculumPlanEntryRepository.findFirstByAcademicYearAndMetaGroupIdAndSubject_IdAndCurriculumPartAndEducationLevelAndStudyPeriodAndDeprecatedFalse(
                "2025/2026", 501L, 23L, CurriculumPart.CORE, EducationLevel.BASIC, StudyPeriod.YEAR))
                .thenReturn(Optional.of(explicitMeta));
        when(tarifficationProcessingService.addingGroup(any(), any())).thenAnswer(invocation -> invocation.getArgument(0));

        service.processCurrentManualLoad("2025/2026");

        verify(curriculumPlanEntryRepository).findFirstByAcademicYearAndMetaGroupIdAndSubject_IdAndCurriculumPartAndEducationLevelAndStudyPeriodAndDeprecatedFalse(
                "2025/2026", 501L, 23L, CurriculumPart.CORE, EducationLevel.BASIC, StudyPeriod.YEAR);
        verify(curriculumPlanService, never()).findRule(anyString(), anyString(), anyString(), anyString(), any(), any());
    }



    @Test
    void addressScopeFindsSp1ClassOnPhysicalSp2BySchoolBuildingId() {
        ManualLoadEntry row = manualRow("Иванов И.И.", "СП1", "7-А", "Алгебра", 6);
        row.setClassId(701L);
        when(manualLoadEntryRepository.findAllByAcademicYearAndSchoolBuildingId("2025/2026", 36L))
                .thenReturn(List.of(row));

        List<ManualLoadEntry> result = service.findAll("2025/2026", "СП2", "Марии Ульяновой, д.5А", 36L);

        assertEquals(1, result.size());
        assertEquals("СП1", result.get(0).getNumberSchoolBuilding());
        assertEquals(701L, result.get(0).getClassId());
        verify(manualLoadEntryRepository).findAllByAcademicYearAndSchoolBuildingId("2025/2026", 36L);
    }

    @Test
    void addressScopeFindsSp1ClassOnPhysicalSp3BySchoolBuildingId() {
        ManualLoadEntry row = manualRow("Иванов И.И.", "СП1", "10-А", "Алгебра", 6);
        row.setClassId(1001L);
        when(manualLoadEntryRepository.findAllByAcademicYearAndSchoolBuildingId("2025/2026", 38L))
                .thenReturn(List.of(row));

        List<ManualLoadEntry> result = service.findAll("2025/2026", "СП3", "Кравченко, д.14, корп.1", 38L);

        assertEquals(1, result.size());
        assertEquals("СП1", result.get(0).getNumberSchoolBuilding());
        assertEquals("10-А", result.get(0).getClassName());
        verify(manualLoadEntryRepository).findAllByAcademicYearAndSchoolBuildingId("2025/2026", 38L);
    }

    @Test
    void buildingGroupScopeStillFiltersByOrganizationalSp() {
        ManualLoadEntry row = manualRow("Иванов И.И.", "СП1", "7-А", "Алгебра", 6);
        when(manualLoadEntryRepository.findAllByAcademicYearAndNumberSchoolBuildingIgnoreCase("2025/2026", "СП1"))
                .thenReturn(List.of(row));

        List<ManualLoadEntry> result = service.findAll("2025/2026", "СП1", null, null);

        assertEquals(1, result.size());
        assertEquals("СП1", result.get(0).getNumberSchoolBuilding());
        verify(manualLoadEntryRepository).findAllByAcademicYearAndNumberSchoolBuildingIgnoreCase("2025/2026", "СП1");
    }

    @Test
    void addressScopeBulkSaveAcceptsSp1ClassOnSelectedPhysicalSite() {
        ManualLoadEntryRequest request = manualRequest("СП1", "7-А", 701L);
        ManualLoadBulkRequest bulk = new ManualLoadBulkRequest();
        bulk.setAcademicYear("2025/2026");
        bulk.setScopeType("BUILDING_ADDRESS");
        bulk.setNumberSchoolBuilding("СП2");
        bulk.setCampusAddress("Марии Ульяновой, д.5А");
        bulk.setSchoolBuildingId(36L);
        bulk.setClassIds(new java.util.LinkedHashSet<>(List.of(701L)));
        bulk.setRows(List.of(request));
        ClassroomLeadershipEntry classroom = classEntry(701L, "СП1", "7-А", "Марии Ульяновой, д.5А");
        classroom.setSchoolBuilding(schoolBuilding(36L, "СП2", "Марии Ульяновой, д.5А"));
        when(classroomLeadershipRepository.findAllById(any())).thenReturn(List.of(classroom));
        when(manualLoadEntryRepository.saveAll(any())).thenAnswer(invocation -> invocation.getArgument(0));

        List<ManualLoadEntry> saved = service.createBulk(bulk);

        assertEquals(1, saved.size());
        assertEquals("СП1", saved.get(0).getNumberSchoolBuilding());
        assertEquals(701L, saved.get(0).getClassId());
        verify(manualLoadEntryRepository).deleteByAcademicYearAndClassIds("2025/2026", java.util.Set.of(701L));
    }

    @Test
    void addressScopeBulkSaveRejectsClassFromAnotherPhysicalSite() {
        ManualLoadEntryRequest request = manualRequest("СП1", "10-А", 1001L);
        ManualLoadBulkRequest bulk = new ManualLoadBulkRequest();
        bulk.setAcademicYear("2025/2026");
        bulk.setScopeType("BUILDING_ADDRESS");
        bulk.setNumberSchoolBuilding("СП2");
        bulk.setSchoolBuildingId(36L);
        bulk.setClassIds(new java.util.LinkedHashSet<>(List.of(1001L)));
        bulk.setRows(List.of(request));
        ClassroomLeadershipEntry classroom = classEntry(1001L, "СП1", "10-А", "Кравченко, д.14, корп.1");
        classroom.setSchoolBuilding(schoolBuilding(38L, "СП3", "Кравченко, д.14, корп.1"));
        when(classroomLeadershipRepository.findAllById(any())).thenReturn(List.of(classroom));

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class, () -> service.createBulk(bulk));

        assertTrue(error.getMessage().contains("schoolBuildingId=36"));
    }

    @Test
    void clearAddressScopeDeletesOrdinaryRowsBySchoolBuildingId() {
        service.clearBySchoolBuilding("2025/2026", 36L);

        verify(manualLoadEntryRepository).deleteByAcademicYearAndSchoolBuildingId("2025/2026", 36L);
    }


    @Test
    void addressScopeFindsExplicitMetaGroupOnSelectedPhysicalSite() {
        ManualLoadEntry ordinary = manualRow("Иванов И.И.", "СП1", "7-А", "Алгебра", 6);
        ordinary.setClassId(701L);
        ManualLoadEntry explicitMeta = manualRow("Петров П.П.", "СП2", "МГ:4 4ЦЧ-СВЕТСКАЯ", "ОДНКНР", 1);
        explicitMeta.setClassId(null);
        explicitMeta.setMetaGroupId(4L);
        when(manualLoadEntryRepository.findAllByAcademicYearAndSchoolBuildingId("2026/2027", 36L))
                .thenReturn(List.of(ordinary, explicitMeta));

        List<ManualLoadEntry> result = service.findAll("2026/2027", "СП2", "Марии Ульяновой, д.5А", 36L);

        assertEquals(2, result.size());
        assertEquals(701L, result.get(0).getClassId());
        assertEquals(4L, result.get(1).getMetaGroupId());
        assertNull(result.get(1).getClassId());
    }

    @Test
    void addressScopeBulkSaveReplacesExplicitMetaGroupRowsByMetaGroupId() {
        ManualLoadEntryRequest request = manualRequest("СП2", "МГ:4 4ЦЧ-СВЕТСКАЯ", null);
        request.setAcademicYear("2026/2027");
        request.setSubjectName("ОДНКНР");
        request.setLoad(1);
        request.setMetaGroupId(4L);
        ManualLoadBulkRequest bulk = new ManualLoadBulkRequest();
        bulk.setAcademicYear("2026/2027");
        bulk.setScopeType("BUILDING_ADDRESS");
        bulk.setNumberSchoolBuilding("СП2");
        bulk.setSchoolBuildingId(36L);
        bulk.setRows(List.of(request));
        when(metaGroupRepository.findById(4L)).thenReturn(Optional.of(metaGroup(4L, 36L)));
        when(metaGroupRepository.findAllById(java.util.Set.of(4L))).thenReturn(List.of(metaGroup(4L, 36L)));
        when(manualLoadEntryRepository.saveAll(any())).thenAnswer(invocation -> invocation.getArgument(0));

        List<ManualLoadEntry> saved = service.createBulk(bulk);

        assertEquals(1, saved.size());
        assertNull(saved.get(0).getClassId());
        assertEquals(4L, saved.get(0).getMetaGroupId());
        verify(manualLoadEntryRepository).deleteByAcademicYearAndMetaGroupIds("2026/2027", java.util.Set.of(4L));
        verify(manualLoadEntryRepository, never()).deleteByAcademicYearAndBuildingCodes(anyString(), any());
    }

    @Test
    void explicitMetaGroupWithoutPhysicalSiteFailsWithClearMessage() {
        ManualLoadEntryRequest request = manualRequest("СП2", "МГ:4 4ЦЧ-СВЕТСКАЯ", null);
        request.setMetaGroupId(4L);
        when(metaGroupRepository.findById(4L)).thenReturn(Optional.of(metaGroup(4L, null)));

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class, () -> service.createBulk(List.of(request)));

        assertTrue(error.getMessage().contains("Для метагруппы не выбрана физическая площадка проведения"));
        verify(manualLoadEntryRepository, never()).saveAll(any());
    }

    @Test
    void addressScopeBulkSaveRejectsMetaGroupFromAnotherPhysicalSite() {
        ManualLoadEntryRequest request = manualRequest("СП2", "МГ:4 4ЦЧ-СВЕТСКАЯ", null);
        request.setAcademicYear("2026/2027");
        request.setMetaGroupId(4L);
        ManualLoadBulkRequest bulk = new ManualLoadBulkRequest();
        bulk.setAcademicYear("2026/2027");
        bulk.setScopeType("BUILDING_ADDRESS");
        bulk.setNumberSchoolBuilding("СП2");
        bulk.setSchoolBuildingId(36L);
        bulk.setRows(List.of(request));
        when(metaGroupRepository.findById(4L)).thenReturn(Optional.of(metaGroup(4L, 38L)));
        when(metaGroupRepository.findAllById(java.util.Set.of(4L))).thenReturn(List.of(metaGroup(4L, 38L)));

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class, () -> service.createBulk(bulk));

        assertTrue(error.getMessage().contains("metaGroupIds do not belong to selected schoolBuildingId=36"));
        verify(manualLoadEntryRepository, never()).deleteByAcademicYearAndMetaGroupIds(anyString(), any());
        verify(manualLoadEntryRepository, never()).saveAll(any());
    }

    @Test
    void importNewTemplateWithRequiredFkColumnsPersistsOrdinaryAndMetaGroupRows() throws Exception {
        CurriculumPlanEntry ordinaryRule = curriculumRow("СП1", "5-А", "Математика", 5);
        ordinaryRule.setClassId(101L);
        ordinaryRule.setSubject(subject(21L, "Математика"));
        CurriculumPlanEntry explicitMetaRule = curriculumRow("СП1", "МГ:5 ФИЗИКА", "Физика", 3);
        explicitMetaRule.setMetaGroupId(501L);
        explicitMetaRule.setSubject(subject(23L, "Физика"));
        MockMultipartFile file = editableImportFile(true, List.of(
                importRow("СП1", "5-А", "Математика", 5, 101L, null, 10L, 21L),
                importRow("СП1", "МГ:5 ФИЗИКА", "Физика", 3, null, 501L, 10L, 23L)
        ));
        when(curriculumPlanEntryRepository.findFirstByAcademicYearAndClassIdAndSubject_IdAndCurriculumPartAndEducationLevelAndStudyPeriodAndDeprecatedFalse(
                "2025/2026", 101L, 21L, CurriculumPart.CORE, EducationLevel.BASIC, StudyPeriod.YEAR))
                .thenReturn(Optional.of(ordinaryRule));
        when(curriculumPlanEntryRepository.findFirstByAcademicYearAndMetaGroupIdAndSubject_IdAndCurriculumPartAndEducationLevelAndStudyPeriodAndDeprecatedFalse(
                "2025/2026", 501L, 23L, CurriculumPart.CORE, EducationLevel.BASIC, StudyPeriod.YEAR))
                .thenReturn(Optional.of(explicitMetaRule));
        when(manualLoadEntryRepository.saveAll(any())).thenAnswer(invocation -> invocation.getArgument(0));

        List<ManualLoadEntry> saved = service.importWorkbook("2025/2026", file);

        assertEquals(2, saved.size());
        assertEquals(101L, saved.get(0).getClassId());
        assertNull(saved.get(0).getMetaGroupId());
        assertEquals(10L, saved.get(0).getTeacherId());
        assertEquals(21L, saved.get(0).getSubjectId());
        assertNull(saved.get(1).getClassId());
        assertEquals(501L, saved.get(1).getMetaGroupId());
        assertEquals(10L, saved.get(1).getTeacherId());
        assertEquals(23L, saved.get(1).getSubjectId());
    }

    @Test
    void importOldTemplateWithoutFkColumnsIsRejectedWithClearMessage() throws Exception {
        MockMultipartFile file = editableImportFile(false, List.of(
                importRow("СП1", "5-А", "Математика", 5, null, null)
        ));

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class, () -> service.importWorkbook("2025/2026", file));

        assertTrue(error.getMessage().contains("Файл создан в старом формате"));
        assertTrue(error.getMessage().contains("Выгрузите новый шаблон нагрузки"));
        verify(manualLoadEntryRepository, never()).saveAll(any());
    }

    @Test
    void importPreviousFkTemplateWithoutModuleColumnsRemainsSupportedForOrdinaryRows() throws Exception {
        CurriculumPlanEntry ordinaryRule = curriculumRow("СП1", "5-А", "Математика", 5);
        ordinaryRule.setClassId(101L);
        ordinaryRule.setSubject(subject(21L, "Математика"));
        MockMultipartFile file = editableImportFile(true, false, List.of(
                importRow("СП1", "5-А", "Математика", 5, 101L, null, 10L, 21L)
        ));
        when(curriculumPlanEntryRepository.findFirstByAcademicYearAndClassIdAndSubject_IdAndCurriculumPartAndEducationLevelAndStudyPeriodAndDeprecatedFalse(
                "2025/2026", 101L, 21L, CurriculumPart.CORE, EducationLevel.BASIC, StudyPeriod.YEAR))
                .thenReturn(Optional.of(ordinaryRule));
        when(manualLoadEntryRepository.saveAll(any())).thenAnswer(invocation -> invocation.getArgument(0));

        List<ManualLoadEntry> saved = service.importWorkbook("2025/2026", file);

        assertEquals(1, saved.size());
        assertNull(saved.get(0).getCurriculumModuleId());
    }

    @Test
    void importNewTemplateRejectsUnknownForeignKey() throws Exception {
        MockMultipartFile file = editableImportFile(true, List.of(
                importRow("СП1", "5-А", "Математика", 5, 101L, null, 999L, 21L)
        ));

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class, () -> service.importWorkbook("2025/2026", file));

        assertTrue(error.getMessage().contains("teacher_id не найден"));
        verify(manualLoadEntryRepository, never()).saveAll(any());
    }

    @Test
    void importNewTemplateRejectsRowsWithBothClassIdAndMetaGroupId() throws Exception {
        MockMultipartFile file = editableImportFile(true, List.of(
                importRow("СП1", "МГ:5 ФИЗИКА", "Физика", 3, 101L, 501L, 10L, 23L)
        ));

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class, () -> service.importWorkbook("2025/2026", file));

        assertTrue(error.getMessage().contains("нельзя одновременно указывать CLASS_ID и META_GROUP_ID"));
        verify(manualLoadEntryRepository, never()).saveAll(any());
    }

    @Test
    void importNewTemplateRejectsOrdinaryMetaGroupMemberRow() throws Exception {
        CurriculumPlanEntry metaMember = curriculumRow("СП1", "5-Б", "Физика", 3);
        metaMember.setClassId(102L);
        metaMember.setSubject(subject(23L, "Физика"));
        metaMember.setMetaGroup(true);
        metaMember.setExcludedFromManualLoad(true);
        MockMultipartFile file = editableImportFile(true, List.of(
                importRow("СП1", "5-Б", "Физика", 3, 102L, null, 10L, 23L)
        ));
        when(curriculumPlanEntryRepository.findFirstByAcademicYearAndClassIdAndSubject_IdAndCurriculumPartAndEducationLevelAndStudyPeriodAndDeprecatedFalse(
                "2025/2026", 102L, 23L, CurriculumPart.CORE, EducationLevel.BASIC, StudyPeriod.YEAR))
                .thenReturn(Optional.of(metaMember));

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class, () -> service.importWorkbook("2025/2026", file));

        assertTrue(error.getMessage().contains("ordinary member row"));
        verify(manualLoadEntryRepository, never()).saveAll(any());
    }


    @Test
    void exportConsolidatedWorkbookUsesRequestedColumnsAndTeacherPrimarySubject() throws Exception {
        ManualLoadEntry russian = manualRow("Иванова И.И.", "СП1", "5-А", "Русский язык", 6);
        ManualLoadEntry literature = manualRow("Иванова И.И.", "СП1", "5-А", "Литература", 3);
        ManualLoadEntry math = manualRow("Иванова И.И.", "СП3", "5-Б", "Алгебра", 1);
        russian.setTeacherId(10L);
        literature.setTeacherId(10L);
        math.setTeacherId(10L);
        math.setGroupNameEducationalPlan("1 группа");
        ClassroomLeadershipEntry leadership = classEntry("СП1", "5-А", "ул. Первая, 1");
        leadership.setFioTeacher("Иванова И.И.");
        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(russian, literature, math));
        when(subjectLevelCoefficientRepository.findAll()).thenReturn(List.of(coefficient("Алгебра", EducationStage.OOO, "1.3")));
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(leadership));
        when(primarySubjectService.resolveForExport("2025/2026"))
                .thenReturn(Map.of(10L, "Русский язык и литература"));

        byte[] body = service.exportConsolidatedWorkbook("2025/2026");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var sheet = workbook.getSheet("По основному предмету");
            assertNotNull(sheet);
            List<String> expectedHeaders = List.of(
                    "Основной предмет*", "ФИО", "Корпус", "Предмет", "Класс", "Группа", "Период", "Кол-во часов",
                    "ИТОГО Часов", "К-во детей (Норм)", "К-во детей (с К=2)", "К-во детей (с К=3)",
                    "Коэф. Предмета", "Классное руководство"
            );
            for (int i = 0; i < expectedHeaders.size(); i++) {
                assertEquals(expectedHeaders.get(i), sheet.getRow(0).getCell(i).getStringCellValue());
            }
            assertEquals("Русский язык и литература", sheet.getRow(1).getCell(0).getStringCellValue());
            assertEquals("Иванова И.И.", sheet.getRow(1).getCell(1).getStringCellValue());
            assertEquals("ГОД", sheet.getRow(1).getCell(6).getStringCellValue());
            assertEquals("10", sheet.getRow(1).getCell(8).getStringCellValue());
            assertEquals("", sheet.getRow(1).getCell(9).getStringCellValue());
            assertEquals("", sheet.getRow(1).getCell(10).getStringCellValue());
            assertEquals("", sheet.getRow(1).getCell(11).getStringCellValue());
            assertEquals("5-А", sheet.getRow(1).getCell(13).getStringCellValue());
            boolean hasMathCoefficient = false;
            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                if ("Алгебра".equals(sheet.getRow(rowIndex).getCell(3).getStringCellValue())) {
                    assertEquals("1.3", sheet.getRow(rowIndex).getCell(12).getStringCellValue());
                    hasMathCoefficient = true;
                }
            }
            assertTrue(hasMathCoefficient);
            assertTrue(sheet.getMergedRegions().stream().anyMatch(region -> region.getFirstColumn() == 0 && region.getLastColumn() == 0));
            assertTrue(sheet.getMergedRegions().stream().anyMatch(region -> region.getFirstColumn() == 1 && region.getLastColumn() == 1));
            assertTrue(sheet.getMergedRegions().stream().anyMatch(region -> region.getFirstColumn() == 8 && region.getLastColumn() == 8));
            assertTrue(sheet.getMergedRegions().stream().anyMatch(region -> region.getFirstColumn() == 13 && region.getLastColumn() == 13));
        }
    }

    @Test
    void exportConsolidatedWorkbookMarksTeacherAsPrimarySchoolWhenTeachingGradesOneToFour() throws Exception {
        ManualLoadEntry row = manualRow("Петрова П.П.", "СП1", "3-А", "Физика", 2);
        row.setTeacherId(11L);
        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(row));
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of());
        when(primarySubjectService.resolveForExport("2025/2026"))
                .thenReturn(Map.of(11L, "Начальная школа"));

        byte[] body = service.exportConsolidatedWorkbook("2025/2026");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var sheet = workbook.getSheet("По основному предмету");
            assertEquals("Начальная школа", sheet.getRow(1).getCell(0).getStringCellValue());
        }
    }

    @Test
    void exportFullWorkbookShowsRowBuildingAddressAndLeadershipOnly() throws Exception {
        ManualLoadEntry first = manualRow("Иванов И.И.", "СП1", "1-А", "Математика", 5);
        ManualLoadEntry second = manualRow("Иванов И.И.", "СП2", "2-А", "Математика", 4);

        ClassroomLeadershipEntry firstClass = classEntry("СП1", "1-А", "ул. Первая, 1");
        firstClass.setFioTeacher("Иванов И.И.");
        ClassroomLeadershipEntry secondClass = classEntry("СП2", "2-А", "ул. Вторая, 2");

        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(first, second));
        when(teacherDirectoryRepository.findAll()).thenReturn(List.of());
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(firstClass, secondClass));
        when(schoolBuildingRepository.findAll()).thenReturn(List.of());
        when(classSizeService.effectiveClassSizes("2025/2026")).thenReturn(Map.of());

        byte[] body = service.exportFullWorkbook("2025/2026");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var sheet = workbook.getSheet("СП1");
            assertEquals("Всего основных", sheet.getRow(0).getCell(7).getStringCellValue());
            assertEquals("Полная нагрузка", sheet.getRow(0).getCell(8).getStringCellValue());
            assertEquals("Корпус", sheet.getRow(0).getCell(9).getStringCellValue());
            assertEquals("Классное руководство", sheet.getRow(0).getCell(10).getStringCellValue());
            assertTrue(sheet.getRow(1).getCell(9).getStringCellValue().contains("ул. Первая, 1"));
            assertEquals("1-А", sheet.getRow(1).getCell(10).getStringCellValue());
            assertEquals("СП2", sheet.getRow(2).getCell(9).getStringCellValue().split("\n")[0]);
            assertNotNull(workbook.getSheet("Все педагоги"));
        }
    }

    @Test
    void exportFullWorkbookWithSalaryAddsSalaryColumnsAndSummarySheet() throws Exception {
        ManualLoadEntry first = manualRow("Иванов И.И.", "СП1", "1-А", "Математика", 5);
        ManualLoadEntry second = manualRow("Иванов И.И.", "СП1", "2-А", "Математика", 4);
        ClassroomLeadershipEntry firstClass = classEntry("СП1", "1-А", "ул. Первая, 1");
        firstClass.setFioTeacher("Иванов И.И.");

        SubjectCatalogEntry subject = new SubjectCatalogEntry();
        subject.setSubjectName("Математика");
        subject.setSubjectType(SubjectType.CORE);
        subject.setSubjectCoefficient(java.math.BigDecimal.ONE);

        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(first, second));
        when(teacherDirectoryRepository.findAll()).thenReturn(List.of());
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(firstClass));
        when(schoolBuildingRepository.findAll()).thenReturn(List.of());
        SalarySettings settings = new SalarySettings();
        settings.setStudentHourRate(java.math.BigDecimal.valueOf(40));
        when(classSizeService.effectiveClassSizes("2025/2026")).thenReturn(Map.of());
        when(salarySettingsRepository.findById(SalarySettings.DEFAULT_ID)).thenReturn(Optional.of(settings));

        byte[] body = service.exportFullWorkbookWithSalary("2025/2026");
        byte[] salaryOneBody = service.exportSalaryOneWorkbook("2025/2026");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var loadSheet = workbook.getSheet("СП1");
            assertEquals("ГОД", loadSheet.getRow(1).getCell(6).getStringCellValue());
            assertEquals(-1, columnIndex(loadSheet, "Часы внутри ставки"));
            double expectedFirstRow = 40 * 30 * 5 * (34.0 / 12.0);
            double expectedSecondRow = 40 * 30 * 4 * (34.0 / 12.0);
            double expectedHours = expectedFirstRow + expectedSecondRow;
            double expectedLeadership = 500 * 30 + 5000;
            assertEquals(5D, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Часы к оплате")).getNumericCellValue(), 0.01);
            assertEquals(1D, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Предметный коэф.")).getNumericCellValue(), 0.01);
            assertEquals(1D, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Коэф. группы")).getNumericCellValue(), 0.01);
            assertEquals(expectedFirstRow, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "За строку")).getNumericCellValue(), 0.01);
            assertEquals(expectedHours, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "За оплачиваемые часы итого")).getNumericCellValue(), 0.01);
            assertEquals(expectedLeadership, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Классное руководство, руб.")).getNumericCellValue(), 0.01);
            assertEquals(0D, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "ОВЗ и дети-инвалиды, руб.")).getNumericCellValue(), 0.01);
            assertEquals(expectedHours + expectedLeadership, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Итого, руб.")).getNumericCellValue(), 0.01);

            var summarySheet = workbook.getSheet("Свод ЗП");
            assertEquals("Итого по комплексу", summarySheet.getRow(2).getCell(0).getStringCellValue());
            assertEquals(0D, summarySheet.getRow(2).getCell(3).getNumericCellValue(), 0.01);
            assertEquals(expectedHours + expectedLeadership, summarySheet.getRow(2).getCell(4).getNumericCellValue(), 0.01);
        }
        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(salaryOneBody))) {
            var salaryOneSheet = workbook.getSheet("Нагрузка для ЗП 1");
            assertEquals(-1, columnIndex(salaryOneSheet, "Часы внутри ставки"));
            assertEquals(-1, columnIndex(salaryOneSheet, "Основание"));
        }
    }

    @Test
    void exportFullWorkbookWithSalaryKeepsCoreSalaryAndAddsIupCompensationSeparately() throws Exception {
        ManualLoadEntry core = manualRow("Иванов И.И.", "СП1", "5-А", "Математика", 5);
        core.setId(1L);
        core.setTeacherId(10L);
        ManualLoadEntry iup = manualRow("Иванов И.И.", "СП1", "ИУП-5-А-Иванов И.И.", "Математика", 2);
        iup.setId(2L);
        iup.setTeacherId(10L);
        iup.setLoadSource(ManualLoadSource.IUP);
        iup.setPreciseLoadHours(new BigDecimal("2"));
        iup.setIupStudentCategory(StudentCategory.K2);

        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(core, iup));
        when(teacherDirectoryRepository.findAll()).thenReturn(List.of());
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of());
        when(schoolBuildingRepository.findAll()).thenReturn(List.of());
        when(classSizeService.effectiveClassSizes("2025/2026")).thenReturn(Map.of("5-А", 30));
        SalarySettings settings = new SalarySettings();
        settings.setStudentHourRate(new BigDecimal("40"));
        when(salarySettingsRepository.findById(SalarySettings.DEFAULT_ID)).thenReturn(Optional.of(settings));

        byte[] body = service.exportFullWorkbookWithSalary("2025/2026");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var loadSheet = workbook.getSheet("СП1");
            double expectedCoreSalary = 40 * 30 * 5 * (34.0 / 12.0);
            double expectedIupCompensation = new BigDecimal("2")
                    .multiply(BigDecimal.valueOf(34).divide(BigDecimal.valueOf(12), 10, java.math.RoundingMode.HALF_UP))
                    .multiply(new BigDecimal("12.5"))
                    .setScale(2, java.math.RoundingMode.HALF_UP)
                    .doubleValue();
            assertEquals(expectedCoreSalary,
                    loadSheet.getRow(1).getCell(columnIndex(loadSheet, "За оплачиваемые часы итого")).getNumericCellValue(), 0.01);
            assertEquals(expectedIupCompensation,
                    loadSheet.getRow(1).getCell(columnIndex(loadSheet, "ОВЗ и дети-инвалиды, руб.")).getNumericCellValue(), 0.01);
            assertEquals(expectedCoreSalary + expectedIupCompensation,
                    loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Итого, руб.")).getNumericCellValue(), 0.01);

            var summarySheet = workbook.getSheet("Свод ЗП");
            assertEquals(expectedCoreSalary, summarySheet.getRow(2).getCell(1).getNumericCellValue(), 0.01);
            assertEquals(expectedIupCompensation, summarySheet.getRow(2).getCell(3).getNumericCellValue(), 0.01);
            assertEquals(expectedCoreSalary + expectedIupCompensation,
                    summarySheet.getRow(2).getCell(4).getNumericCellValue(), 0.01);
        }
    }

    @Test
    void exportFullWorkbookWithSalaryAddsSubjectAndGroupBonusesFromBaseSalary() throws Exception {
        ManualLoadEntry row = manualRow("Иванов И.И.", "СП1", "5-А", "Труд (технология)", 6);
        row.setSubject(subject(20L, "Труд (технология)"));
        row.setGroupNameEducationalPlan("1 группа");

        SalaryGroupCoefficientSubject groupSubject = new SalaryGroupCoefficientSubject();
        groupSubject.setSubjectId(20L);
        groupSubject.setSubjectName("Труд (технология)");

        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(row));
        when(teacherDirectoryRepository.findAll()).thenReturn(List.of());
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of());
        when(schoolBuildingRepository.findAll()).thenReturn(List.of());
        when(classSizeService.effectiveClassSizes("2025/2026")).thenReturn(Map.of("5-А", 30));
        when(subjectLevelCoefficientRepository.findAll()).thenReturn(List.of(
                coefficient("Труд (технология)", EducationStage.NOO, "1.1"),
                coefficient("Труд (технология)", EducationStage.OOO, "1.5")
        ));
        when(salaryGroupCoefficientSubjectRepository.findAll()).thenReturn(List.of(groupSubject));
        SalarySettings settings = new SalarySettings();
        settings.setStudentHourRate(java.math.BigDecimal.valueOf(40));
        when(salarySettingsRepository.findById(SalarySettings.DEFAULT_ID)).thenReturn(Optional.of(settings));

        byte[] body = service.exportFullWorkbookWithSalary("2025/2026");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var loadSheet = workbook.getSheet("СП1");
            double base = 40 * 15 * 6 * (34.0 / 12.0);
            double subjectBonus = base * (1.5 - 1);
            double groupBonus = base * ((25.0 / 15.0) - 1);
            double expected = base + subjectBonus + groupBonus;
            assertEquals(1.5D, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Предметный коэф.")).getNumericCellValue(), 0.01);
            assertEquals(25.0 / 15.0, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Коэф. группы")).getNumericCellValue(), 0.01);
            assertEquals(expected, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "За строку")).getNumericCellValue(), 0.01);
            assertEquals(expected, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "За оплачиваемые часы итого")).getNumericCellValue(), 0.01);
            assertEquals(expected, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Итого, руб.")).getNumericCellValue(), 0.01);
        }
    }


    @Test
    void exportSubjectLoadWorkbookSeparatesHalfYearHoursWithPipe() throws Exception {
        ManualLoadEntry firstHalf = manualRow("Петров П.П.", "СП1", "5-А", "Математика", 1);
        firstHalf.setStudyPeriod(StudyPeriod.H1);
        ManualLoadEntry secondHalf = manualRow("Петров П.П.", "СП1", "5-А", "Математика", 2);
        secondHalf.setStudyPeriod(StudyPeriod.H2);

        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(firstHalf, secondHalf));
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of());
        when(schoolBuildingRepository.findAll()).thenReturn(List.of());

        byte[] body = service.exportSubjectLoadWorkbook("2025/2026", "", "");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var sheet = workbook.getSheet("Комплекс");
            assertNotNull(sheet);
            assertEquals("часов\nпредмет/площадка/комплекс", sheet.getRow(2).getCell(2).getStringCellValue());
            assertEquals("1 | 2 / 1 | 2 / 1 | 2", sheet.getRow(3).getCell(2).getStringCellValue());
            assertEquals("1 | 2", sheet.getRow(3).getCell(3).getStringCellValue());
        }
    }


    @Test
    void exportSubjectLoadWorkbookFormatsSubjectAddressAndComplexHoursReadably() throws Exception {
        ManualLoadEntry subject = manualRow("Петров П.П.", "СП1", "5-А", "Математика", 2);
        ManualLoadEntry addressFirstHalf = manualRow("Петров П.П.", "СП1", "5-А", "Физика", 13);
        addressFirstHalf.setStudyPeriod(StudyPeriod.H1);
        ManualLoadEntry addressSecondHalf = manualRow("Петров П.П.", "СП1", "5-А", "Физика", 18);
        addressSecondHalf.setStudyPeriod(StudyPeriod.H2);
        ManualLoadEntry complexFirstHalf = manualRow("Петров П.П.", "СП2", "6-Б", "Физика", 5);
        complexFirstHalf.setStudyPeriod(StudyPeriod.H1);
        ManualLoadEntry complexSecondHalf = manualRow("Петров П.П.", "СП2", "6-Б", "Физика", 1);
        complexSecondHalf.setStudyPeriod(StudyPeriod.H2);

        ClassroomLeadershipEntry firstAddressClass = classEntry("СП1", "5-А", "ул. Первая, 1");
        ClassroomLeadershipEntry secondAddressClass = classEntry("СП2", "6-Б", "ул. Вторая, 2");

        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026"))
                .thenReturn(List.of(subject, addressFirstHalf, addressSecondHalf, complexFirstHalf, complexSecondHalf));
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026"))
                .thenReturn(List.of(firstAddressClass, secondAddressClass));
        when(schoolBuildingRepository.findAll()).thenReturn(List.of());

        byte[] body = service.exportSubjectLoadWorkbook("2025/2026", "", "");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var sheet = workbook.getSheet("ул. Первая, 1");
            assertNotNull(sheet);
            assertEquals("Математика", sheet.getRow(3).getCell(0).getStringCellValue());
            assertEquals("2 / 15 | 20 / 20 | 21", sheet.getRow(3).getCell(2).getStringCellValue());
        }
    }

    @Test
    void exportFullWorkbookWithSalaryShowsHalfYearTotalsAndFirstHalfMoney() throws Exception {
        ManualLoadEntry year = manualRow("Петров П.П.", "СП1", "3-А", "Математика", 10);
        ManualLoadEntry firstHalf = manualRow("Петров П.П.", "СП1", "3-А", "Математика", 1);
        firstHalf.setStudyPeriod(StudyPeriod.H1);
        ManualLoadEntry secondHalf = manualRow("Петров П.П.", "СП1", "3-А", "Математика", 2);
        secondHalf.setStudyPeriod(StudyPeriod.H2);

        SubjectCatalogEntry subject = new SubjectCatalogEntry();
        subject.setSubjectName("Математика");
        subject.setSubjectType(SubjectType.CORE);
        subject.setSubjectCoefficient(java.math.BigDecimal.ONE);

        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(year, firstHalf, secondHalf));
        when(teacherDirectoryRepository.findAll()).thenReturn(List.of());
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of());
        when(schoolBuildingRepository.findAll()).thenReturn(List.of());
        SalarySettings settings = new SalarySettings();
        settings.setStudentHourRate(java.math.BigDecimal.valueOf(40));
        when(classSizeService.effectiveClassSizes("2025/2026")).thenReturn(Map.of());
        when(salarySettingsRepository.findById(SalarySettings.DEFAULT_ID)).thenReturn(Optional.of(settings));

        byte[] body = service.exportFullWorkbookWithSalary("2025/2026");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(body))) {
            var loadSheet = workbook.getSheet("СП1");
            assertEquals("11 | 12", loadSheet.getRow(1).getCell(7).getStringCellValue());
            double expectedRowMoney = 40 * 30 * 10 * (34.0 / 12.0);
            double expectedFirstHalfHoursMoney = 40 * 30 * 11 * (34.0 / 12.0);
            assertEquals(expectedRowMoney, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "За строку")).getNumericCellValue(), 0.01);
            assertEquals(expectedFirstHalfHoursMoney, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "За оплачиваемые часы итого")).getNumericCellValue(), 0.01);
            assertEquals(expectedFirstHalfHoursMoney, loadSheet.getRow(1).getCell(columnIndex(loadSheet, "Итого, руб.")).getNumericCellValue(), 0.01);
        }
    }

    @Test
    void salaryExportsShowInsideRateColumnsOnlyWhenTheyContainHours() throws Exception {
        ManualLoadEntry row = manualRow("Иванов И.И.", "СП1", "5-А", "ОБЗР", 6);
        row.setIncludedInRateHours(new BigDecimal("4"));
        row.setInRateReason("Внутри ставки преподавателя ОБЗР");
        when(manualLoadEntryRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of(row));
        when(teacherDirectoryRepository.findAll()).thenReturn(List.of());
        when(classroomLeadershipRepository.findAllByAcademicYear("2025/2026")).thenReturn(List.of());
        when(schoolBuildingRepository.findAll()).thenReturn(List.of());
        when(classSizeService.effectiveClassSizes("2025/2026")).thenReturn(Map.of());

        byte[] fullBody = service.exportFullWorkbookWithSalary("2025/2026");
        byte[] salaryOneBody = service.exportSalaryOneWorkbook("2025/2026");

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(fullBody))) {
            var sheet = workbook.getSheet("СП1");
            assertTrue(columnIndex(sheet, "Часы внутри ставки") >= 0);
            assertTrue(columnIndex(sheet, "Основание") >= 0);
            assertEquals(4D, sheet.getRow(1).getCell(columnIndex(sheet, "Часы внутри ставки")).getNumericCellValue(), 0.01);
        }
        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(salaryOneBody))) {
            var sheet = workbook.getSheet("Нагрузка для ЗП 1");
            assertTrue(columnIndex(sheet, "Часы внутри ставки") >= 0);
            assertTrue(columnIndex(sheet, "Основание") >= 0);
            assertEquals(4D, sheet.getRow(1).getCell(columnIndex(sheet, "Часы внутри ставки")).getNumericCellValue(), 0.01);
        }
    }


    private MockMultipartFile editableImportFile(boolean includeFkColumns, List<ImportRow> rows) throws Exception {
        return editableImportFile(includeFkColumns, true, rows);
    }

    private MockMultipartFile editableImportFile(boolean includeFkColumns,
                                                 boolean includeModuleColumns,
                                                 List<ImportRow> rows) throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            var sheet = workbook.createSheet("LOAD_EDITABLE");
            var header = sheet.createRow(0);
            String[] headers = {"Учебный год", "Корпус", "Класс", "Предмет", "Группа", "Период", "С", "По", "Часы", "Уровень", "ФИО педагога", "ROW_KEY", "CLASS_ID", "META_GROUP_ID", "TEACHER_ID", "SUBJECT_ID", "CURRICULUM_PART", "CURRICULUM_MODULE_ID", "MODULE_NAME"};
            int headerCount = includeFkColumns ? (includeModuleColumns ? headers.length : 17) : 12;
            for (int i = 0; i < headerCount; i++) {
                header.createCell(i).setCellValue(headers[i]);
            }
            for (int i = 0; i < rows.size(); i++) {
                ImportRow source = rows.get(i);
                var row = sheet.createRow(i + 1);
                row.createCell(0).setCellValue("2025/2026");
                row.createCell(1).setCellValue(source.building());
                row.createCell(2).setCellValue(source.className());
                row.createCell(3).setCellValue(source.subject());
                row.createCell(4).setCellValue("");
                row.createCell(5).setCellValue("YEAR");
                row.createCell(6).setCellValue("2025-09-01");
                row.createCell(7).setCellValue("2026-05-31");
                row.createCell(8).setCellValue(source.load());
                row.createCell(9).setCellValue("BASIC");
                row.createCell(10).setCellValue("Вакансия");
                row.createCell(11).setCellValue("row-" + i);
                if (includeFkColumns) {
                    if (source.classId() != null) row.createCell(12).setCellValue(source.classId());
                    if (source.metaGroupId() != null) row.createCell(13).setCellValue(source.metaGroupId());
                    if (source.teacherId() != null) row.createCell(14).setCellValue(source.teacherId());
                    if (source.subjectId() != null) row.createCell(15).setCellValue(source.subjectId());
                    row.createCell(16).setCellValue("CORE");
                    if (includeModuleColumns) {
                        row.createCell(17).setCellValue("");
                        row.createCell(18).setCellValue("");
                    }
                }
            }
            workbook.write(out);
            return new MockMultipartFile("file", "load.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", out.toByteArray());
        }
    }

    private ImportRow importRow(String building, String className, String subject, int load, Long classId, Long metaGroupId) {
        return importRow(building, className, subject, load, classId, metaGroupId, null, null);
    }

    private ImportRow importRow(String building, String className, String subject, int load, Long classId, Long metaGroupId, Long teacherId, Long subjectId) {
        return new ImportRow(building, className, subject, load, classId, metaGroupId, teacherId, subjectId);
    }

    private record ImportRow(String building, String className, String subject, int load, Long classId, Long metaGroupId, Long teacherId, Long subjectId) {
    }

    private CurriculumPlanEntry curriculumRow(String building, String className, String subject, int hours) {
        CurriculumPlanEntry row = new CurriculumPlanEntry();
        row.setAcademicYear("2025/2026");
        row.setNumberSchoolBuilding(building);
        row.setClassName(className);
        row.setSubjectName(subject);
        row.setPlannedHours(BigDecimal.valueOf(hours));
        row.setEducationLevel(EducationLevel.BASIC);
        row.setStudyPeriod(StudyPeriod.YEAR);
        row.setSubgroupRequired(false);
        row.setSubgroupCount(0);
        row.setDeprecated(false);
        return row;
    }

    private ManualLoadEntryRequest manualRequest(String building, String className, Long classId) {
        ManualLoadEntryRequest request = new ManualLoadEntryRequest();
        request.setAcademicYear("2025/2026");
        request.setFioTeacher("Иванов И.И.");
        request.setNumberSchoolBuilding(building);
        request.setSubjectName("Алгебра");
        request.setSubjectId(20L);
        request.setClassName(className);
        request.setClassId(classId);
        request.setTeacherId(10L);
        request.setLoad(6);
        request.setEducationLevel(EducationLevel.BASIC);
        request.setLoadFromDate(LocalDate.of(2025, 9, 1));
        request.setLoadToDate(LocalDate.of(2026, 5, 31));
        return request;
    }

    private ManualLoadEntry manualRow(String fio, String building, String className, String subject, int load) {
        ManualLoadEntry row = new ManualLoadEntry();
        row.setAcademicYear("2025/2026");
        row.setFioTeacher(fio);
        row.setNumberSchoolBuilding(building);
        row.setClassName(className);
        row.setSubjectName(subject);
        row.setLoad(load);
        row.setEducationLevel(EducationLevel.BASIC);
        row.setStudyPeriod(StudyPeriod.YEAR);
        return row;
    }

    private int columnIndex(org.apache.poi.ss.usermodel.Sheet sheet, String header) {
        var row = sheet.getRow(0);
        for (int column = 0; column < row.getLastCellNum(); column++) {
            if (header.equals(row.getCell(column).getStringCellValue())) {
                return column;
            }
        }
        return -1;
    }

    private TeacherDirectoryEntry teacher(Long id, String fio) {
        TeacherDirectoryEntry teacher = new TeacherDirectoryEntry();
        teacher.setId(id);
        teacher.setFioTeacher(fio);
        return teacher;
    }

    private SubjectLevelCoefficientEntry coefficient(String subjectName, EducationStage stage, String coefficient) {
        SubjectLevelCoefficientEntry entry = new SubjectLevelCoefficientEntry();
        entry.setSubjectName(subjectName);
        entry.setEducationStage(stage);
        entry.setCoefficient(new BigDecimal(coefficient));
        return entry;
    }

    private SubjectCatalogEntry subject(Long id, String name) {
        SubjectCatalogEntry subject = new SubjectCatalogEntry();
        subject.setId(id);
        subject.setSubjectName(name);
        subject.setSubjectType(SubjectType.CORE);
        subject.setSubjectCoefficient(java.math.BigDecimal.ONE);
        return subject;
    }

    private MetaGroup metaGroup(Long id, Long schoolBuildingId) {
        MetaGroup metaGroup = new MetaGroup();
        metaGroup.setId(id);
        metaGroup.setNumberSchoolBuilding("СП1");
        metaGroup.setParallel(5);
        metaGroup.setName("5 ФИЗИКА");
        metaGroup.setClassType("NORMAL");
        if (schoolBuildingId != null) {
            metaGroup.setSchoolBuilding(schoolBuilding(schoolBuildingId, "СП2", "Марии Ульяновой, д.5А"));
        }
        return metaGroup;
    }

    private SchoolBuilding schoolBuilding(Long id, String code, String address) {
        SchoolBuilding building = new SchoolBuilding();
        building.setId(id);
        building.setCode(code);
        building.setName(code);
        building.setManagerFio("Ответственный");
        building.setAddress(address);
        return building;
    }

    private ClassroomLeadershipEntry classEntry(Long id, String building, String className, String address, Long schoolBuildingId) {
        ClassroomLeadershipEntry entry = classEntry(id, building, className, address);
        entry.setSchoolBuilding(schoolBuilding(schoolBuildingId, building, address));
        return entry;
    }

    private ClassroomLeadershipEntry classEntry(Long id, String building, String className, String address) {
        ClassroomLeadershipEntry entry = classEntry(building, className, address);
        entry.setId(id);
        return entry;
    }

    private ClassroomLeadershipEntry classEntry(String building, String className, String address) {
        ClassroomLeadershipEntry entry = new ClassroomLeadershipEntry();
        entry.setAcademicYear("2025/2026");
        entry.setNumberSchoolBuilding(building);
        entry.setClassName(className);
        entry.setClassDirection("общеобразовательный");
        entry.setFioTeacher("Классный руководитель");
        entry.setCampusAddress(address);
        return entry;
    }

}
